<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/opencart/{name}/admin/');
define('HTTP_CATALOG', 'http://localhost/opencart/{name}/');

// HTTPS
define('HTTPS_SERVER', 'http://localhost/opencart/{name}/admin/');
define('HTTPS_CATALOG', 'http://localhost/opencart/{name}/');

// DIR
define('DIR_APPLICATION', '{drive}:\xampp\htdocs\opencart/{name}/admin/');
define('DIR_SYSTEM', '{drive}:\xampp\htdocs\opencart/{name}/system/');
define('DIR_IMAGE', '{drive}:\xampp\htdocs\opencart/{name}/image/');
define('DIR_LANGUAGE', '{drive}:\xampp\htdocs\opencart/{name}/admin/language/');
define('DIR_TEMPLATE', '{drive}:\xampp\htdocs\opencart/{name}/admin/view/template/');
define('DIR_CONFIG', '{drive}:\xampp\htdocs\opencart/{name}/system/config/');
define('DIR_CACHE', '{drive}:\xampp\htdocs\opencart/{name}/system/storage/cache/');
define('DIR_DOWNLOAD', '{drive}:\xampp\htdocs\opencart/{name}/system/storage/download/');
define('DIR_LOGS', '{drive}:\xampp\htdocs\opencart/{name}/system/storage/logs/');
define('DIR_MODIFICATION', '{drive}:\xampp\htdocs\opencart/{name}/system/storage/modification/');
define('DIR_UPLOAD', '{drive}:\xampp\htdocs\opencart/{name}/system/storage/upload/');
define('DIR_CATALOG', '{drive}:\xampp\htdocs\opencart/{name}/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', '{name}');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
